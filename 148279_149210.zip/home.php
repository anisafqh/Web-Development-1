<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
	<meta charset="utf-8">
	<title>GoType Home</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="home.css" type="text/css">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>

<body>
<nav>
	<input type="checkbox" id="check">
	<label for="check" class="checkbtn">
		<i class="fas fa-bars"></i>
	</label>
	<label class="logo">GoType</label>
	<ul>
		<li><a class="active">Home</a></li>
		<li><a href="start.php">Start</a></li>
	</ul>
  
	<h1>WELCOME TO GoType <br/><br/> Go Easy with GoType <br/> Your Notes, Your Way</h1>
	<div class="phrases">
		<h2>START, WRITE and SAVE!</h2>
		<h3>Capture your notes, journals, ideas and goals by typing on GoType now.</h3>
	</div>
</nav>
	<section class="one"></section>
	<section class="two"></section>
</body>
</html>
